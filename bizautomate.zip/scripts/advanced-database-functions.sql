-- Advanced analytics functions for BizAutoMate

-- Lead Metrics with Growth Rate
CREATE OR REPLACE FUNCTION get_lead_metrics(
  user_id UUID,
  start_date TIMESTAMP,
  end_date TIMESTAMP
)
RETURNS JSON AS $$
DECLARE
  current_leads INTEGER;
  previous_leads INTEGER;
  conversion_rate DECIMAL;
  average_score DECIMAL;
  result JSON;
BEGIN
  -- Current period leads
  SELECT COUNT(*) INTO current_leads
  FROM leads 
  WHERE user_id = $1 
    AND created_at BETWEEN start_date AND end_date;
  
  -- Previous period leads (same duration)
  SELECT COUNT(*) INTO previous_leads
  FROM leads 
  WHERE user_id = $1 
    AND created_at BETWEEN (start_date - (end_date - start_date)) AND start_date;
  
  -- Conversion rate
  SELECT 
    CASE 
      WHEN COUNT(*) > 0 THEN 
        COUNT(CASE WHEN status = 'Converted' THEN 1 END)::DECIMAL / COUNT(*)
      ELSE 0 
    END INTO conversion_rate
  FROM leads 
  WHERE user_id = $1 
    AND created_at BETWEEN start_date AND end_date;
  
  -- Average lead score
  SELECT COALESCE(AVG(score), 0) INTO average_score
  FROM lead_scores ls
  JOIN leads l ON ls.lead_id = l.id
  WHERE l.user_id = $1 
    AND l.created_at BETWEEN start_date AND end_date;
  
  result := json_build_object(
    'total_leads', current_leads,
    'growth_rate', 
      CASE 
        WHEN previous_leads > 0 THEN 
          (current_leads - previous_leads)::DECIMAL / previous_leads
        ELSE 0 
      END,
    'conversion_rate', conversion_rate,
    'average_score', average_score
  );
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Conversion Funnel Analysis
CREATE OR REPLACE FUNCTION get_conversion_funnel(
  user_id UUID,
  start_date TIMESTAMP,
  end_date TIMESTAMP
)
RETURNS JSON AS $$
DECLARE
  total_leads INTEGER;
  contacted_leads INTEGER;
  qualified_leads INTEGER;
  converted_leads INTEGER;
  result JSON;
BEGIN
  SELECT COUNT(*) INTO total_leads
  FROM leads 
  WHERE user_id = $1 AND created_at BETWEEN start_date AND end_date;
  
  SELECT COUNT(*) INTO contacted_leads
  FROM leads 
  WHERE user_id = $1 
    AND created_at BETWEEN start_date AND end_date
    AND status IN ('Contacted', 'Follow-up', 'Qualified', 'Converted');
  
  SELECT COUNT(*) INTO qualified_leads
  FROM leads 
  WHERE user_id = $1 
    AND created_at BETWEEN start_date AND end_date
    AND status IN ('Qualified', 'Converted');
  
  SELECT COUNT(*) INTO converted_leads
  FROM leads 
  WHERE user_id = $1 
    AND created_at BETWEEN start_date AND end_date
    AND status = 'Converted';
  
  result := json_build_array(
    json_build_object(
      'stage', 'New Leads',
      'count', total_leads,
      'conversion_rate', 100
    ),
    json_build_object(
      'stage', 'Contacted',
      'count', contacted_leads,
      'conversion_rate', 
        CASE WHEN total_leads > 0 THEN 
          ROUND((contacted_leads::DECIMAL / total_leads * 100), 1)
        ELSE 0 END
    ),
    json_build_object(
      'stage', 'Qualified',
      'count', qualified_leads,
      'conversion_rate', 
        CASE WHEN total_leads > 0 THEN 
          ROUND((qualified_leads::DECIMAL / total_leads * 100), 1)
        ELSE 0 END
    ),
    json_build_object(
      'stage', 'Converted',
      'count', converted_leads,
      'conversion_rate', 
        CASE WHEN total_leads > 0 THEN 
          ROUND((converted_leads::DECIMAL / total_leads * 100), 1)
        ELSE 0 END
    )
  );
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Revenue Analytics with Forecasting
CREATE OR REPLACE FUNCTION get_revenue_analytics(
  user_id UUID,
  start_date TIMESTAMP,
  end_date TIMESTAMP
)
RETURNS JSON AS $$
DECLARE
  total_revenue DECIMAL;
  previous_revenue DECIMAL;
  growth_rate DECIMAL;
  avg_deal_size DECIMAL;
  result JSON;
BEGIN
  -- Current period revenue
  SELECT COALESCE(SUM(amount), 0) INTO total_revenue
  FROM payments 
  WHERE user_id = $1 
    AND status = 'Paid'
    AND paid_at BETWEEN start_date AND end_date;
  
  -- Previous period revenue
  SELECT COALESCE(SUM(amount), 0) INTO previous_revenue
  FROM payments 
  WHERE user_id = $1 
    AND status = 'Paid'
    AND paid_at BETWEEN (start_date - (end_date - start_date)) AND start_date;
  
  -- Growth rate
  growth_rate := CASE 
    WHEN previous_revenue > 0 THEN 
      (total_revenue - previous_revenue) / previous_revenue
    ELSE 0 
  END;
  
  -- Average deal size
  SELECT COALESCE(AVG(amount), 0) INTO avg_deal_size
  FROM payments 
  WHERE user_id = $1 
    AND status = 'Paid'
    AND paid_at BETWEEN start_date AND end_date;
  
  result := json_build_object(
    'total_revenue', total_revenue,
    'growth_rate', growth_rate,
    'avg_deal_size', avg_deal_size,
    'forecast', json_build_object(
      'next_month', total_revenue * (1 + growth_rate),
      'next_quarter', total_revenue * (1 + growth_rate) * 3
    )
  );
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Customer Lifetime Value Calculation
CREATE OR REPLACE FUNCTION calculate_customer_ltv(user_id UUID)
RETURNS JSON AS $$
DECLARE
  avg_ltv DECIMAL;
  avg_lifespan DECIMAL;
  avg_purchase_frequency DECIMAL;
  result JSON;
BEGIN
  WITH customer_metrics AS (
    SELECT 
      l.id,
      COALESCE(SUM(p.amount), 0) as total_spent,
      COUNT(p.id) as purchase_count,
      EXTRACT(DAYS FROM (MAX(p.paid_at) - MIN(p.paid_at))) as lifespan_days
    FROM leads l
    LEFT JOIN payments p ON l.id = p.lead_id AND p.status = 'Paid'
    WHERE l.user_id = $1 AND l.status = 'Converted'
    GROUP BY l.id
  )
  SELECT 
    COALESCE(AVG(total_spent), 0),
    COALESCE(AVG(NULLIF(lifespan_days, 0)), 365),
    COALESCE(AVG(NULLIF(purchase_count, 0)), 1)
  INTO avg_ltv, avg_lifespan, avg_purchase_frequency
  FROM customer_metrics;
  
  result := json_build_object(
    'average_ltv', avg_ltv,
    'average_lifespan_days', avg_lifespan,
    'average_purchase_frequency', avg_purchase_frequency
  );
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Churn Analysis
CREATE OR REPLACE FUNCTION analyze_customer_churn(
  user_id UUID,
  start_date TIMESTAMP,
  end_date TIMESTAMP
)
RETURNS JSON AS $$
DECLARE
  high_risk INTEGER;
  medium_risk INTEGER;
  low_risk INTEGER;
  result JSON;
BEGIN
  -- Count customers by churn risk level
  SELECT 
    COUNT(CASE WHEN cp.risk_level = 'high' THEN 1 END),
    COUNT(CASE WHEN cp.risk_level = 'medium' THEN 1 END),
    COUNT(CASE WHEN cp.risk_level = 'low' THEN 1 END)
  INTO high_risk, medium_risk, low_risk
  FROM churn_predictions cp
  JOIN leads l ON cp.customer_id = l.id
  WHERE l.user_id = $1
    AND cp.predicted_at >= start_date;
  
  result := json_build_object(
    'high_risk', high_risk,
    'medium_risk', medium_risk,
    'low_risk', low_risk,
    'total_analyzed', high_risk + medium_risk + low_risk
  );
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Automation Performance Metrics
CREATE OR REPLACE FUNCTION get_automation_performance(
  user_id UUID,
  start_date TIMESTAMP,
  end_date TIMESTAMP
)
RETURNS JSON AS $$
DECLARE
  total_messages INTEGER;
  success_rate DECIMAL;
  time_saved INTEGER;
  efficiency_score DECIMAL;
  result JSON;
BEGIN
  -- Total automated messages
  SELECT COUNT(*) INTO total_messages
  FROM whatsapp_messages wm
  JOIN leads l ON wm.lead_id = l.id
  WHERE l.user_id = $1 
    AND wm.direction = 'outbound'
    AND wm.created_at BETWEEN start_date AND end_date;
  
  -- Success rate (messages delivered successfully)
  SELECT 
    CASE 
      WHEN COUNT(*) > 0 THEN 
        COUNT(CASE WHEN status = 'sent' THEN 1 END)::DECIMAL / COUNT(*)
      ELSE 0 
    END INTO success_rate
  FROM whatsapp_messages wm
  JOIN leads l ON wm.lead_id = l.id
  WHERE l.user_id = $1 
    AND wm.direction = 'outbound'
    AND wm.created_at BETWEEN start_date AND end_date;
  
  -- Estimated time saved (assuming 2 minutes per manual message)
  time_saved := total_messages * 2 / 60; -- Convert to hours
  
  -- Efficiency score based on automation logs
  SELECT COALESCE(AVG(
    CASE 
      WHEN al.status = 'success' THEN 1.0
      ELSE 0.0 
    END
  ), 0) INTO efficiency_score
  FROM automation_logs al
  JOIN automations a ON al.automation_id = a.id
  WHERE a.user_id = $1
    AND al.executed_at BETWEEN start_date AND end_date;
  
  result := json_build_object(
    'total_messages', total_messages,
    'success_rate', success_rate,
    'time_saved', time_saved,
    'efficiency_score', efficiency_score
  );
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Create additional tables for advanced features
CREATE TABLE IF NOT EXISTS lead_scores (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
  score INTEGER NOT NULL CHECK (score >= 0 AND score <= 100),
  priority VARCHAR(20) NOT NULL,
  reasoning TEXT,
  next_actions TEXT[],
  conversion_probability DECIMAL(3,2),
  scored_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS churn_predictions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID REFERENCES leads(id) ON DELETE CASCADE,
  churn_probability DECIMAL(3,2) NOT NULL,
  risk_level VARCHAR(20) NOT NULL,
  risk_factors TEXT[],
  recommended_actions TEXT[],
  predicted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_workflows (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  triggers JSONB NOT NULL,
  actions JSONB NOT NULL,
  priority INTEGER DEFAULT 5,
  business_type VARCHAR(100),
  goals TEXT,
  challenges TEXT,
  status VARCHAR(20) DEFAULT 'draft',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS lead_interactions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
  interaction_type VARCHAR(50) NOT NULL,
  details JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_lead_scores_lead_id ON lead_scores(lead_id);
CREATE INDEX IF NOT EXISTS idx_churn_predictions_customer_id ON churn_predictions(customer_id);
CREATE INDEX IF NOT EXISTS idx_ai_workflows_user_id ON ai_workflows(user_id);
CREATE INDEX IF NOT EXISTS idx_lead_interactions_lead_id ON lead_interactions(lead_id);
