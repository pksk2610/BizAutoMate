import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"
import { getUserFromSession } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { action, data } = await request.json()
    const supabase = createClient()

    switch (action) {
      case "create_lead":
        return await handleCreateLead(data, user.id, supabase)
      case "update_lead_status":
        return await handleUpdateLeadStatus(data, user.id, supabase)
      case "create_payment":
        return await handleCreatePayment(data, user.id, supabase)
      case "send_whatsapp":
        return await handleSendWhatsApp(data, user.id)
      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("Zapier Integration error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function handleCreateLead(data: any, userId: string, supabase: any) {
  const { data: lead, error } = await supabase
    .from("leads")
    .insert({
      user_id: userId,
      name: data.name,
      email: data.email,
      phone: data.phone,
      source: data.source || "Zapier",
      value: data.value || 0,
      notes: data.notes || "",
      created_at: new Date().toISOString(),
    })
    .select()
    .single()

  if (error) {
    return NextResponse.json({ error: "Failed to create lead" }, { status: 500 })
  }

  // Trigger automation
  await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/automation/trigger`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      trigger: "new_lead",
      leadId: lead.id,
    }),
  })

  return NextResponse.json({ success: true, lead })
}

async function handleUpdateLeadStatus(data: any, userId: string, supabase: any) {
  const { data: lead, error } = await supabase
    .from("leads")
    .update({
      status: data.status,
      updated_at: new Date().toISOString(),
    })
    .eq("id", data.leadId)
    .eq("user_id", userId)
    .select()
    .single()

  if (error) {
    return NextResponse.json({ error: "Failed to update lead" }, { status: 500 })
  }

  return NextResponse.json({ success: true, lead })
}

async function handleCreatePayment(data: any, userId: string, supabase: any) {
  // Create Razorpay payment link
  const razorpay = new (require("razorpay"))({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  })

  const paymentLink = await razorpay.paymentLink.create({
    amount: data.amount * 100,
    currency: "INR",
    description: data.description,
    customer: {
      email: data.customerEmail,
      contact: data.customerPhone,
    },
  })

  const { data: payment, error } = await supabase
    .from("payments")
    .insert({
      user_id: userId,
      lead_id: data.leadId,
      amount: data.amount,
      description: data.description,
      status: "Pending",
      razorpay_payment_link_id: paymentLink.id,
      payment_link_url: paymentLink.short_url,
      created_at: new Date().toISOString(),
    })
    .select()
    .single()

  if (error) {
    return NextResponse.json({ error: "Failed to create payment" }, { status: 500 })
  }

  return NextResponse.json({ success: true, payment, paymentLink: paymentLink.short_url })
}

async function handleSendWhatsApp(data: any, userId: string) {
  const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/whatsapp/send`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      to: data.phone,
      message: data.message,
      leadId: data.leadId,
    }),
  })

  const result = await response.json()
  return NextResponse.json(result)
}
