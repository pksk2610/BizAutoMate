import { type NextRequest, NextResponse } from "next/server"
import { openai } from "@ai-sdk/openai"
import { generateObject } from "ai"
import { z } from "zod"
import { createClient } from "@/lib/supabase"
import { getUserFromSession } from "@/lib/auth"

const workflowSchema = z.object({
  name: z.string(),
  description: z.string(),
  triggers: z.array(
    z.object({
      type: z.string(),
      conditions: z.record(z.any()),
    }),
  ),
  actions: z.array(
    z.object({
      type: z.string(),
      parameters: z.record(z.any()),
      delay: z.number().optional(),
    }),
  ),
  priority: z.number().min(1).max(10),
})

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { businessType, goals, currentChallenges } = await request.json()
    const supabase = createClient()

    // Get user's existing data for context
    const [leadsData, paymentsData, automationsData] = await Promise.all([
      supabase.from("leads").select("*").eq("user_id", user.id).limit(100),
      supabase.from("payments").select("*").eq("user_id", user.id).limit(50),
      supabase.from("automations").select("*").eq("user_id", user.id),
    ])

    // AI-powered workflow generation
    const { object: workflow } = await generateObject({
      model: openai("gpt-4o"),
      schema: workflowSchema,
      prompt: `
        Create an intelligent automation workflow for a ${businessType} business.
        
        Business Context:
        - Business Type: ${businessType}
        - Goals: ${goals}
        - Current Challenges: ${currentChallenges}
        
        Current Data:
        - Total Leads: ${leadsData.data?.length || 0}
        - Total Payments: ${paymentsData.data?.length || 0}
        - Existing Automations: ${automationsData.data?.length || 0}
        
        Create a workflow that addresses their specific challenges and helps achieve their goals.
        Consider triggers like:
        - new_lead, lead_no_response, payment_overdue, high_value_lead, etc.
        
        Consider actions like:
        - send_whatsapp, send_email, create_task, update_lead_score, schedule_followup, etc.
        
        Make it specific to their business type and current situation.
      `,
    })

    // Save the AI-generated workflow
    const { data: savedWorkflow, error } = await supabase
      .from("ai_workflows")
      .insert({
        user_id: user.id,
        name: workflow.name,
        description: workflow.description,
        triggers: workflow.triggers,
        actions: workflow.actions,
        priority: workflow.priority,
        business_type: businessType,
        goals: goals,
        challenges: currentChallenges,
        status: "draft",
        created_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: "Failed to save workflow" }, { status: 500 })
    }

    // Generate implementation steps
    const implementationSteps = await generateImplementationSteps(workflow, businessType)

    return NextResponse.json({
      success: true,
      workflow: savedWorkflow,
      implementationSteps,
      estimatedImpact: await calculateEstimatedImpact(workflow, leadsData.data || []),
    })
  } catch (error) {
    console.error("AI Workflow Generation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function generateImplementationSteps(workflow: any, businessType: string) {
  return [
    {
      step: 1,
      title: "Review Workflow",
      description: `Review the generated workflow: "${workflow.name}"`,
      estimated_time: "5 minutes",
      status: "pending",
    },
    {
      step: 2,
      title: "Customize Messages",
      description: "Customize WhatsApp and email templates for your brand voice",
      estimated_time: "15 minutes",
      status: "pending",
    },
    {
      step: 3,
      title: "Test Workflow",
      description: "Run a test with sample data to ensure everything works",
      estimated_time: "10 minutes",
      status: "pending",
    },
    {
      step: 4,
      title: "Activate Workflow",
      description: "Activate the workflow to start automating your business",
      estimated_time: "2 minutes",
      status: "pending",
    },
  ]
}

async function calculateEstimatedImpact(workflow: any, leads: any[]) {
  const totalLeads = leads.length
  const avgLeadValue = leads.reduce((sum, lead) => sum + (lead.value || 0), 0) / totalLeads || 0

  return {
    timesSaved: `${workflow.actions.length * 5} minutes per lead`,
    potentialRevenue: `₹${(avgLeadValue * 0.15 * totalLeads).toLocaleString()}`,
    conversionImprovement: "15-25%",
    responseTime: "Instant (vs 2-4 hours manual)",
  }
}
