import { type NextRequest, NextResponse } from "next/server"
import { GoogleSpreadsheet } from "google-spreadsheet"
import { JWT } from "google-auth-library"

export async function POST(request: NextRequest) {
  try {
    const lead = await request.json()

    // Initialize Google Sheets
    const serviceAccountAuth = new JWT({
      email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
      key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
    })

    const doc = new GoogleSpreadsheet(process.env.GOOGLE_SHEET_ID!, serviceAccountAuth)
    await doc.loadInfo()

    const sheet = doc.sheetsByIndex[0] // First sheet

    // Add lead to sheet
    await sheet.addRow({
      Date: new Date().toLocaleDateString("en-IN"),
      Name: lead.name,
      Email: lead.email,
      Phone: lead.phone,
      Source: lead.source,
      Status: lead.status,
      Value: lead.value,
      Notes: lead.notes,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Google Sheets error:", error)
    return NextResponse.json({ error: "Failed to add to Google Sheets" }, { status: 500 })
  }
}
