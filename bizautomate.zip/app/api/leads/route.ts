import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"
import { getUserFromSession } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromSession(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const supabase = createClient()

    const { data: leads, error } = await supabase
      .from("leads")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching leads:", error)
      return NextResponse.json({ error: "Failed to fetch leads" }, { status: 500 })
    }

    return NextResponse.json({ leads })
  } catch (error) {
    console.error("Leads API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { name, email, phone, source, value, notes } = await request.json()

    // Validate required fields
    if (!name || !email || !phone) {
      return NextResponse.json({ error: "Name, email, and phone are required" }, { status: 400 })
    }

    const supabase = createClient()

    const { data: lead, error } = await supabase
      .from("leads")
      .insert({
        user_id: user.id,
        name,
        email,
        phone,
        source: source || "Manual",
        status: "New",
        value: value || 0,
        notes: notes || "",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      console.error("Error creating lead:", error)
      return NextResponse.json({ error: "Failed to create lead" }, { status: 500 })
    }

    // Trigger automation for new lead
    await triggerNewLeadAutomation(lead)

    return NextResponse.json({ success: true, lead })
  } catch (error) {
    console.error("Create lead error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function triggerNewLeadAutomation(lead: any) {
  try {
    // Send welcome WhatsApp message
    await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/whatsapp/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to: lead.phone,
        message: `Hi ${lead.name}! 👋 Thank you for your interest in our services. We'll get back to you shortly!`,
        leadId: lead.id,
      }),
    })

    // Add to Google Sheets
    await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/sheets/add-lead`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(lead),
    })
  } catch (error) {
    console.error("Automation trigger error:", error)
  }
}
