import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js" // Declare the createClient import

export async function POST(request: NextRequest) {
  try {
    const { to, message, leadId } = await request.json()

    // WhatsApp Business API integration
    const whatsappResponse = await fetch(
      `https://graph.facebook.com/v18.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          to: to.replace(/\D/g, ""), // Remove non-digits
          type: "text",
          text: {
            body: message,
          },
        }),
      },
    )

    const result = await whatsappResponse.json()

    if (!whatsappResponse.ok) {
      console.error("WhatsApp API error:", result)
      return NextResponse.json({ error: "Failed to send WhatsApp message" }, { status: 500 })
    }

    // Log message in database
    const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY) // Initialize Supabase client
    await supabase.from("whatsapp_messages").insert({
      lead_id: leadId,
      phone_number: to,
      message,
      direction: "outbound",
      status: "sent",
      whatsapp_message_id: result.messages[0].id,
      created_at: new Date().toISOString(),
    })

    return NextResponse.json({ success: true, messageId: result.messages[0].id })
  } catch (error) {
    console.error("WhatsApp send error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
