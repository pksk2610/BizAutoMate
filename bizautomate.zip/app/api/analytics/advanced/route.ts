import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"
import { getUserFromSession } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromSession(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const period = searchParams.get("period") || "30d"
    const supabase = createClient()

    // Calculate date range
    const endDate = new Date()
    const startDate = new Date()
    switch (period) {
      case "7d":
        startDate.setDate(endDate.getDate() - 7)
        break
      case "30d":
        startDate.setDate(endDate.getDate() - 30)
        break
      case "90d":
        startDate.setDate(endDate.getDate() - 90)
        break
      case "1y":
        startDate.setFullYear(endDate.getFullYear() - 1)
        break
    }

    // Advanced analytics queries
    const [
      leadMetrics,
      conversionFunnel,
      revenueAnalytics,
      automationPerformance,
      customerLifetimeValue,
      churnAnalysis,
    ] = await Promise.all([
      // Lead Metrics with Growth Rate
      supabase.rpc("get_lead_metrics", {
        user_id: user.id,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
      }),

      // Conversion Funnel Analysis
      supabase.rpc("get_conversion_funnel", {
        user_id: user.id,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
      }),

      // Revenue Analytics with Forecasting
      supabase.rpc("get_revenue_analytics", {
        user_id: user.id,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
      }),

      // Automation Performance Metrics
      supabase.rpc("get_automation_performance", {
        user_id: user.id,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
      }),

      // Customer Lifetime Value
      supabase.rpc("calculate_customer_ltv", {
        user_id: user.id,
      }),

      // Churn Analysis
      supabase.rpc("analyze_customer_churn", {
        user_id: user.id,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
      }),
    ])

    // AI-powered insights
    const insights = await generateBusinessInsights({
      leadMetrics: leadMetrics.data,
      conversionFunnel: conversionFunnel.data,
      revenueAnalytics: revenueAnalytics.data,
      automationPerformance: automationPerformance.data,
    })

    return NextResponse.json({
      success: true,
      analytics: {
        leadMetrics: leadMetrics.data,
        conversionFunnel: conversionFunnel.data,
        revenueAnalytics: revenueAnalytics.data,
        automationPerformance: automationPerformance.data,
        customerLifetimeValue: customerLifetimeValue.data,
        churnAnalysis: churnAnalysis.data,
        aiInsights: insights,
        period,
        generatedAt: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("Advanced Analytics error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function generateBusinessInsights(data: any) {
  // AI-powered business insights generation
  const insights = []

  // Lead Quality Analysis
  if (data.leadMetrics?.conversion_rate < 0.15) {
    insights.push({
      type: "warning",
      category: "Lead Quality",
      message: "Conversion rate is below industry average (15%). Consider improving lead qualification.",
      impact: "high",
      actionItems: ["Review lead sources", "Implement lead scoring", "Optimize qualification process"],
    })
  }

  // Revenue Growth Insights
  if (data.revenueAnalytics?.growth_rate > 0.2) {
    insights.push({
      type: "success",
      category: "Revenue Growth",
      message: `Excellent revenue growth of ${(data.revenueAnalytics.growth_rate * 100).toFixed(1)}%!`,
      impact: "high",
      actionItems: ["Scale successful campaigns", "Increase marketing budget", "Expand team capacity"],
    })
  }

  // Automation Efficiency
  if (data.automationPerformance?.efficiency_score > 0.8) {
    insights.push({
      type: "success",
      category: "Automation",
      message: "Your automation workflows are performing exceptionally well.",
      impact: "medium",
      actionItems: ["Replicate successful automations", "A/B test message variations", "Expand automation scope"],
    })
  }

  return insights
}
