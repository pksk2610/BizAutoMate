import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"
import { getUserFromSession } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const supabase = createClient()

    // Get customer data for churn prediction
    const { data: customers, error } = await supabase
      .from("leads")
      .select(`
        *,
        payments(amount, created_at, status),
        whatsapp_messages(created_at, direction),
        lead_interactions(interaction_type, created_at)
      `)
      .eq("user_id", user.id)
      .eq("status", "Converted")

    if (error) {
      return NextResponse.json({ error: "Failed to fetch customer data" }, { status: 500 })
    }

    // Calculate churn risk features for each customer
    const churnPredictions = customers.map((customer) => {
      const features = calculateChurnFeatures(customer)
      const churnRisk = predictChurnRisk(features)

      return {
        customerId: customer.id,
        customerName: customer.name,
        churnRisk: churnRisk.risk,
        churnProbability: churnRisk.probability,
        riskFactors: churnRisk.factors,
        recommendedActions: churnRisk.actions,
        features,
      }
    })

    // Sort by churn risk (highest first)
    churnPredictions.sort((a, b) => b.churnProbability - a.churnProbability)

    // Save predictions to database
    await Promise.all(
      churnPredictions.map((prediction) =>
        supabase.from("churn_predictions").upsert({
          customer_id: prediction.customerId,
          churn_probability: prediction.churnProbability,
          risk_level: prediction.churnRisk,
          risk_factors: prediction.riskFactors,
          recommended_actions: prediction.recommendedActions,
          predicted_at: new Date().toISOString(),
        }),
      ),
    )

    return NextResponse.json({
      success: true,
      predictions: churnPredictions,
      summary: {
        totalCustomers: customers.length,
        highRisk: churnPredictions.filter((p) => p.churnRisk === "high").length,
        mediumRisk: churnPredictions.filter((p) => p.churnRisk === "medium").length,
        lowRisk: churnPredictions.filter((p) => p.churnRisk === "low").length,
      },
    })
  } catch (error) {
    console.error("Churn Prediction error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

function calculateChurnFeatures(customer: any) {
  const now = new Date()
  const customerAge = (now.getTime() - new Date(customer.created_at).getTime()) / (1000 * 60 * 60 * 24) // days

  // Payment behavior features
  const payments = customer.payments || []
  const totalRevenue = payments.reduce((sum: number, p: any) => sum + (p.amount || 0), 0)
  const avgPaymentAmount = payments.length > 0 ? totalRevenue / payments.length : 0
  const daysSinceLastPayment =
    payments.length > 0
      ? (now.getTime() - new Date(Math.max(...payments.map((p: any) => new Date(p.created_at).getTime()))).getTime()) /
        (1000 * 60 * 60 * 24)
      : customerAge

  // Engagement features
  const messages = customer.whatsapp_messages || []
  const totalMessages = messages.length
  const inboundMessages = messages.filter((m: any) => m.direction === "inbound").length
  const outboundMessages = messages.filter((m: any) => m.direction === "outbound").length
  const responseRate = outboundMessages > 0 ? inboundMessages / outboundMessages : 0
  const daysSinceLastMessage =
    messages.length > 0
      ? (now.getTime() - new Date(Math.max(...messages.map((m: any) => new Date(m.created_at).getTime()))).getTime()) /
        (1000 * 60 * 60 * 24)
      : customerAge

  // Interaction features
  const interactions = customer.lead_interactions || []
  const totalInteractions = interactions.length
  const daysSinceLastInteraction =
    interactions.length > 0
      ? (now.getTime() -
          new Date(Math.max(...interactions.map((i: any) => new Date(i.created_at).getTime()))).getTime()) /
        (1000 * 60 * 60 * 24)
      : customerAge

  return {
    customerAge,
    totalRevenue,
    avgPaymentAmount,
    daysSinceLastPayment,
    totalMessages,
    responseRate,
    daysSinceLastMessage,
    totalInteractions,
    daysSinceLastInteraction,
    paymentFrequency: payments.length / (customerAge / 30), // payments per month
  }
}

function predictChurnRisk(features: any) {
  let riskScore = 0
  const factors = []
  const actions = []

  // Payment-based risk factors
  if (features.daysSinceLastPayment > 60) {
    riskScore += 30
    factors.push("No recent payments (60+ days)")
    actions.push("Send payment reminder")
  }

  if (features.totalRevenue < 5000) {
    riskScore += 20
    factors.push("Low total revenue")
    actions.push("Offer value-added services")
  }

  // Engagement-based risk factors
  if (features.daysSinceLastMessage > 30) {
    riskScore += 25
    factors.push("No recent communication")
    actions.push("Send re-engagement message")
  }

  if (features.responseRate < 0.3) {
    riskScore += 15
    factors.push("Low response rate")
    actions.push("Improve message personalization")
  }

  // Interaction-based risk factors
  if (features.daysSinceLastInteraction > 45) {
    riskScore += 20
    factors.push("No recent interactions")
    actions.push("Schedule follow-up call")
  }

  // Determine risk level
  let risk: "low" | "medium" | "high"
  if (riskScore >= 70) {
    risk = "high"
    actions.push("Immediate intervention required")
  } else if (riskScore >= 40) {
    risk = "medium"
    actions.push("Monitor closely")
  } else {
    risk = "low"
    actions.push("Continue regular engagement")
  }

  return {
    risk,
    probability: Math.min(riskScore / 100, 0.95),
    factors,
    actions,
  }
}
