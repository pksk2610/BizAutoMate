import { type NextRequest, NextResponse } from "next/server"
import { openai } from "@ai-sdk/openai"
import { generateObject } from "ai"
import { z } from "zod"
import { createClient } from "@/lib/supabase"
import { getUserFromSession } from "@/lib/auth"

const leadScoringSchema = z.object({
  score: z.number().min(0).max(100),
  priority: z.enum(["low", "medium", "high", "urgent"]),
  reasoning: z.string(),
  nextActions: z.array(z.string()),
  conversionProbability: z.number().min(0).max(1),
})

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { leadId } = await request.json()
    const supabase = createClient()

    // Get lead data with interaction history
    const { data: lead, error } = await supabase
      .from("leads")
      .select(`
        *,
        whatsapp_messages(*),
        payments(*),
        lead_interactions(*)
      `)
      .eq("id", leadId)
      .single()

    if (error || !lead) {
      return NextResponse.json({ error: "Lead not found" }, { status: 404 })
    }

    // AI-powered lead scoring
    const { object: scoring } = await generateObject({
      model: openai("gpt-4o"),
      schema: leadScoringSchema,
      prompt: `
        Analyze this lead and provide a comprehensive scoring:
        
        Lead Details:
        - Name: ${lead.name}
        - Email: ${lead.email}
        - Phone: ${lead.phone}
        - Source: ${lead.source}
        - Business Value: ₹${lead.value}
        - Created: ${lead.created_at}
        - Status: ${lead.status}
        - Notes: ${lead.notes}
        
        Interaction History:
        - WhatsApp Messages: ${lead.whatsapp_messages?.length || 0}
        - Payment History: ${lead.payments?.length || 0} payments
        - Total Interactions: ${lead.lead_interactions?.length || 0}
        
        Consider factors like:
        1. Engagement level (response rate, message frequency)
        2. Business value potential
        3. Time since last interaction
        4. Source quality
        5. Payment history
        6. Behavioral patterns
        
        Provide actionable insights for sales team.
      `,
    })

    // Save scoring to database
    await supabase.from("lead_scores").upsert({
      lead_id: leadId,
      score: scoring.score,
      priority: scoring.priority,
      reasoning: scoring.reasoning,
      next_actions: scoring.nextActions,
      conversion_probability: scoring.conversionProbability,
      scored_at: new Date().toISOString(),
    })

    return NextResponse.json({ success: true, scoring })
  } catch (error) {
    console.error("AI Lead Scoring error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
