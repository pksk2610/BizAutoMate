import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"
import crypto from "crypto"

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get("x-razorpay-signature")

    // Verify webhook signature
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET!)
      .update(body)
      .digest("hex")

    if (signature !== expectedSignature) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    const event = JSON.parse(body)
    const supabase = createClient()

    if (event.event === "payment_link.paid") {
      // Update payment status
      await supabase
        .from("payments")
        .update({
          status: "Paid",
          razorpay_payment_id: event.payload.payment.entity.id,
          paid_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq("razorpay_payment_link_id", event.payload.payment_link.entity.id)

      // Send confirmation WhatsApp message
      const { data: payment } = await supabase
        .from("payments")
        .select("*, leads(*)")
        .eq("razorpay_payment_link_id", event.payload.payment_link.entity.id)
        .single()

      if (payment && payment.leads) {
        await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/whatsapp/send`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            to: payment.leads.phone,
            message: `Hi ${payment.leads.name}! 🎉 Your payment of ₹${payment.amount} has been received successfully. Thank you for your business!`,
            leadId: payment.lead_id,
          }),
        })
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Razorpay webhook error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
