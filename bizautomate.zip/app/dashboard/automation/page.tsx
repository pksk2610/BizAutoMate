import Link from "next/link"
import { ArrowLeft, Bell, Bot, MessageSquare, Play, Plus, Settings, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"

export default function AutomationPage() {
  const automations = [
    {
      id: 1,
      name: "Welcome Message",
      description: "Auto-reply to new WhatsApp contacts",
      status: "Active",
      triggers: 245,
      success: 98,
    },
    {
      id: 2,
      name: "Payment Reminder",
      description: "Send payment reminders for overdue invoices",
      status: "Active",
      triggers: 67,
      success: 85,
    },
    {
      id: 3,
      name: "Lead Follow-up",
      description: "Follow up with new leads after 24 hours",
      status: "Paused",
      triggers: 123,
      success: 76,
    },
    {
      id: 4,
      name: "Booking Confirmation",
      description: "Confirm appointments and send details",
      status: "Active",
      triggers: 89,
      success: 94,
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard" className="flex items-center space-x-2">
              <ArrowLeft className="w-5 h-5" />
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">BizAutoMate</span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Bell className="w-5 h-5" />
            </Button>
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <span className="text-white text-sm font-medium">RK</span>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Automation Center</h1>
          <p className="text-gray-600">Set up and manage your business automation workflows</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Automations</CardTitle>
              <Bot className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">8</div>
              <p className="text-xs text-green-600">3 new this week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Messages Sent</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,245</div>
              <p className="text-xs text-blue-600">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">89%</div>
              <p className="text-xs text-green-600">Above average</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Time Saved</CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24 hrs</div>
              <p className="text-xs text-purple-600">Per week</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Setup */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Quick Setup</CardTitle>
            <CardDescription>Get started with popular automation templates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="cursor-pointer hover:shadow-md transition-shadow border-dashed border-2">
                <CardContent className="p-6 text-center">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 text-green-600" />
                  <h3 className="font-semibold mb-1">WhatsApp Auto-Reply</h3>
                  <p className="text-sm text-gray-600 mb-3">Respond to customer messages instantly</p>
                  <Button size="sm" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Setup Now
                  </Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow border-dashed border-2">
                <CardContent className="p-6 text-center">
                  <Bell className="w-8 h-8 mx-auto mb-2 text-orange-600" />
                  <h3 className="font-semibold mb-1">Payment Reminders</h3>
                  <p className="text-sm text-gray-600 mb-3">Automate overdue payment follow-ups</p>
                  <Button size="sm" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Setup Now
                  </Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow border-dashed border-2">
                <CardContent className="p-6 text-center">
                  <Bot className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                  <h3 className="font-semibold mb-1">Lead Nurturing</h3>
                  <p className="text-sm text-gray-600 mb-3">Follow up with potential customers</p>
                  <Button size="sm" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Setup Now
                  </Button>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        {/* Active Automations */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Your Automations</CardTitle>
                <CardDescription>Manage and monitor your active workflows</CardDescription>
              </div>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create Automation
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {automations.map((automation) => (
                <Card key={automation.id} className="border-l-4 border-l-blue-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Bot className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">{automation.name}</h3>
                          <p className="text-gray-600 text-sm">{automation.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge
                          className={
                            automation.status === "Active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                          }
                        >
                          {automation.status}
                        </Badge>
                        <Switch checked={automation.status === "Active"} />
                        <Button variant="ghost" size="icon">
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <div className="text-sm text-gray-600 mb-1">Triggers This Month</div>
                        <div className="text-2xl font-bold text-blue-600">{automation.triggers}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600 mb-1">Success Rate</div>
                        <div className="flex items-center space-x-2">
                          <div className="text-2xl font-bold text-green-600">{automation.success}%</div>
                          <Progress value={automation.success} className="flex-1 h-2" />
                        </div>
                      </div>
                      <div className="flex items-center justify-end space-x-2">
                        <Button variant="outline" size="sm">
                          <Play className="w-4 h-4 mr-2" />
                          Test Run
                        </Button>
                        <Button variant="outline" size="sm">
                          View Logs
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
