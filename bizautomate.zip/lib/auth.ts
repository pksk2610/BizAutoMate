import type { NextRequest } from "next/server"
import { createClient } from "./supabase"

export async function getUserFromSession(request: NextRequest) {
  try {
    const sessionCookie = request.cookies.get("user_session")
    if (!sessionCookie) {
      return null
    }

    const supabase = createClient()
    const { data: user, error } = await supabase.from("users").select("*").eq("id", sessionCookie.value).single()

    if (error || !user) {
      return null
    }

    return user
  } catch (error) {
    console.error("Auth error:", error)
    return null
  }
}
